﻿/* Assembly Properties c: */

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("GRACE")]
[assembly: AssemblyDescription("I like fluffy things")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Fluff Ballin")]
[assembly: AssemblyProduct("src")]
[assembly: AssemblyCopyright("Copyright © Grace 2019")]
[assembly: AssemblyTrademark("Grace The Great")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("79992a0e-c06f-45a5-957b-a384672eb786")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
