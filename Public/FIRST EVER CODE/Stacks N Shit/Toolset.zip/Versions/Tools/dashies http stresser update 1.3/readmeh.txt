
--
--------
-------------
---
-

another improvement update, 1.3 for the HTTP Stresser, be sure to
test everything out as I have been working hard on this.

for more information open up the Update Log through the app itself.
Yup, I added it!

All I can say is that this is a part like update, only specific
parts of this update are present as a bigger one is most likely
to come real soon, Port Scanner and such all in one.

----
---------
------
---
-

(c) All Rights Reserved, Dashies Software Inc.

- Dashie