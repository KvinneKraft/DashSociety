Dashies Software � All Rights Reserved.
---------------
----------------------
--------

Okay, so, I have made a little free DoS tool for y�ll.
Feel free to share it as it does actually work.

I wrote the entire application, and did not use any shitty designers.
Instead I rewrote a big part of the .NET Framework, since a big part 
of it is frigging annoying. lol, so you will most likely not get
the same result as my compiled version when you compile my codes.

anywehs, just know that too many workers or too less workers can be fatal.
and know that this is as illegal as eating shit in public, you get the point.

now, the updated version will most likely come with an advanced port scanner
, uh some exploits, some automated sql injection technologies, spoofed headers
, https support and uhm, a port scanner, for TCP, UDP and other shitty protocols.

this app currently makes use of vulnerabilities within sockets, so yeh.
http sockets it is, well tcp/http sockets, i will be upgrading its being as
soon as i feel like it, now i am going to eat a donut and leave you alone
with wasted time. no problem senior.