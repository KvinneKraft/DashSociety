Okay, so, I have figured, that I should apply some new functionality
and some code optimization techniques to this application as it seems
like that I have a little bit more up my sleeve for this application.

I was thinking about some extra options, such as :
$"{Port}, {TCP}, {UDP}, {Sockets}" and some other
iterate attacks which will attack the given target
from different angles, we will also be sure to add 
in HTTPS Support. 

Just see what has changed yourself, as it be that I am writting
this before I even started coding the 1.2 update.

again, the source has been rewritten and compiled with a newer updated
modified version of the .NET Framework.

(c) All Rights Reserved, Dashies Software Inc.

--------
----
---- oof, too lazy to do fancy chips my dear.
----
--------


-Dashie

"Oof, also, I have compressed the sources more than before.
 Before I released 1.0 the file was 500 KB, which has after
 all come down to 94KB, which will soon either be less or 
 more, just see it yourself, imma add in manifestation now too."