(c) All Rights Reserved, Dashies Software Inc.

---------
----------------
---------------------------------
-----------
-------


Hey, seems like you the version 1.4, ahaha, yes you do!

this update is focused on performance, layout and flexibility, a lot more
things have been implemented this time, a lot of attack methods, attack types
and a lot of more little tweaks and functionality extensions. I have even
managed to add in our own protocol. even though the file size has been increased
it has been increased in lines of code, not graphics. I have been so
fucking busy with this piece of shit that it finally works. after a lot
of testing and messing around I found out that my DashLoris Technique is the 
most powerful, bypassing and effective attack against Apache Servers. 

- Look in the attack_info.txt

i may actually implement a custom size-preset in 1.5, who knows.

Too much talking right here, open up da fucking app and look at the logs I
implemented lazy shit!


=====================================

-Dashie